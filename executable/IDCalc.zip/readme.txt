In the zip there should be two files.  1) IDCalc.exe and 2) COMDLG32.OCX

Copy the module COMDLG32.OCX and save it to the Windows\System32 or Windows\SysWOW64 folder. On Windows 64-bit systems, copy the OCX file to: C:\Windows\SysWOW64. On Windows 32-bit systems, copy the OCX file to C:\Windows\System32.

You then need to register that library.  From the command line you can do that by typing.

For Windows 64-bit systems:

regsvr32  C:\Windows\SysWOW64\COMDLG32.OCX
For Windows 32-bit systems:

regsvr32  C:\Windows\System32\COMDLG32.OCX

After that is registered you should be able to double click the IDCalc.exe and it should run.  If not let me know.  

This is an old program written in visual basic that isn't that easy to support on modern Windows systems.  This COMDL32.OCX file is a library from an old windows computer.
